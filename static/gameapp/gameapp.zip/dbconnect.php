<?php
//$connect=mysqli_connect("localhost","iotcl6k4_iotuser","IOTcloud@2021","iotcl6k4_projectdb2");
$connect=mysqli_connect("localhost","iotclwps_iotuser","IOTcloud@2021","iotclwps_projectdb2");

?>